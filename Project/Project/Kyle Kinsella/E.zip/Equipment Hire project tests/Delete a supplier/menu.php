<!DOCTYPE html>
<html>
<head>


<div class="menu">
  <ul>
    <li><a href="insert.html">Add a Record</a></li>
    <li><a href="display.php">Display Details</a></li>
    <li><a href="amendView.html.php">Amend/View Details</a></li>
    <li><a href="PersonReport.html.php">Report</a></li>
  </ul>
</div>


</head>
</html>	