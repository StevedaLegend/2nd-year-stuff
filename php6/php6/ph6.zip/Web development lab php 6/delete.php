<?php   session_start();
include 'db.inc.php';

$sql = "UPDATE Persons SET DeletedFlag = true WHERE personid = '$_POST[delid]'";

if (! mysqli_query($con,$sql ))
{
    echo "Error ".mysqli_error($con);
}

$_SESSION["personid"] = $_POST['delid'];
$_SESSION["firstname"] = $_POST['delfirstname'];
$_SESSION["lastname"] = $_POST['dellastname'];

mysqli_close($con);
?>

<script>

window.location = "Delete.html.php"
</script>